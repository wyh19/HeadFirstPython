from distutils.core import setup

setup(
    name='nester',
    version='1.0.0',
    py_modules=['nester'],
    author='wyh',
    author_email='wyh_19@163.com',
    url='',
    description=''
)
